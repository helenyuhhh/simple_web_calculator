window.onload = function() {
  var res = "";
  var first = "";
  var second = "";
  var firstNum = 0;
  var secNum = 0;
  var result = 0;
  var captions = ['7','8','9','/','AC','4','5','6','x','1','2',
                  '3','-','=','0','.','+'];


  for (var i = 1; i <= 17; i++) {
    var button = document.createElement("button");
    button.setAttribute("id", "btn" + i);
    button.innerHTML=(captions[i-1]);
    $("#buttons").append(button);
    //button.style.display="grid";
    button.style.border="none";
    button.style.backgroundColor="rgb(201, 204, 209)";
    button.style.boxShadow="0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19)";
    //button.style.hover.backgroundColor="grey";

  }
  //button style======================================

  //h1 style==========================================
  $("h1").css("text-align", "center");
  $("h1").css("background-color", "LightGrey");
  //body style=========================================
  $("body").css("background-color", "silver");
  //calc style========================================
  $("#cal").css("width", "315px");
  $("#cal").css("height", "460px");
  $("#cal").css("border", "solid 2px grey");
  $("#cal").css("margin-left", "38%");
  $("#cal").css("background-color", "rgb(186, 191, 212)");


  //output style=======================================
  $("#output").css("text-align", "right");
  $("#output").css("margin-left", "2.5%");
  $("#output").css("width", "300px");
  $("#output").css("height", "70px");
  $("#output").css("border", "solid 2px DarkGrey");
  $("#output").css("border-radius", "10px");
  $("#output").css("margin-bottom", "10px");
  $("#output").css("margin-top", "3px");
  $("#output").css("background-color", "rgb(130, 131, 135)");
  $("#output").css("font-size", "30px");

  //button style========================================
  $("#buttons").css("display", "grid");
  $("#buttons").css("grid-template-columns", "auto auto auto auto auto");
  $("#buttons").css("grid-gap", "2px");
  $("#buttons").css("width", "300px");
  $("#buttons").css("height", "350px");
  $("#buttons").css("margin-left", "2.5%");
  //$("#buttons").observe("mouseover", mouseOver);
  //$("#buttons").css("background-color", "silver");

  //$("#btn1").observe("mouseover", mouseOver);
  //0 button style =================================
  $("#btn15").css("grid-column-end", "span 2");
  //AC key style============================================
  $("#btn5").css("grid-row-end", "span 2");
  $("#btn5").css("background-color", "red");

  //= key style==============================================
  $("#btn14").css("grid-row-end", "span 2");
  $("#btn14").css("background-color", "rgb(130, 131, 135)");


  //$("#buttons").css("grid-template-columns", "auto auto auto auto auto");
  //$(".button").css("grid-gap", "10px");
  //$(".button").css("padding", "20px 0");
  //sign button style===================================================
  $("#btn4").css("background-color", "rgb(130, 131, 135)");
  $("#btn9").css("background-color", "rgb(130, 131, 135)");
  $("#btn13").css("background-color", "rgb(130, 131, 135)");
  $("#btn17").css("background-color", "rgb(130, 131, 135)");

  $("button").mouseenter(function(){
    $(this).css("background-color", "rgb(92, 113, 122)");

  });
  $("button").mouseout(function(){
    $(this).css("background-color", "rgb(201, 204, 209)");
    $("#btn14").css("background-color", "rgb(130, 131, 135)");
    $("#btn5").css("background-color", "red");
    $("#btn4").css("background-color", "rgb(130, 131, 135)");
    $("#btn9").css("background-color", "rgb(130, 131, 135)");
    $("#btn13").css("background-color", "rgb(130, 131, 135)");
    $("#btn17").css("background-color", "rgb(130, 131, 135)");

  });

  //==========================end of styleing==================================
  //==========================start of function================================
  //===========================================================================

document.addEventListener("keypress", addStr);
//document.addEventListener("keypress", addOp);
$("#btn1").click("click", addString);
$("#btn2").click("click", addString);
$("#btn3").click("click", addString);
$("#btn4").click("click", addString);
$("#btn6").click("click", addString);
$("#btn7").click("click", addString);
$("#btn8").click("click", addString);
$("#btn9").click("click", addString);
$("#btn10").click("click", addString);
$("#btn11").click("click", addString);
$("#btn12").click("click", addString);
$("#btn13").click("click", addString);
$("#btn15").click("click", addString);
$("#btn16").click("click", addString);
$("#btn17").click("click", addString);

  // = sign is pressed======
  $("#btn14").click(function(){
    var out = determine(res);
    $("#output").html(out);
    res = out.toString();
  }
  );
  // AC sign is pressed
  $("#btn5").click(function(){
    res = "";
    //result = 0;
    $("#output").html("0");
  }
);



  function determine(res) {
    //determing the arithmatic symbol in the string
    var opI = 0;
    var i = 0;
    while (i < res.length) {
      if (res.charAt(i) == "+" ||res.charAt(i) == "-"|| res.charAt(i) == "x" || res.charAt(i) == "/") {
        break;
      }
      else {
        i = i + 1;
      }
    }
    first = res.substring(0, i); // first part before the math symbol
    second = res.substring(i+1);

   // the second part after the math symbol no = symbol
    if (checkDec(first) == true) {
       firstNum = parseFloat(first);
    }
    else {
       firstNum = parseInt(first);
    }

    if (checkDec(second) == true) {
       secNum = parseFloat(second);
    }
    else {
       secNum = parseInt(second);
    }
    if (res.charAt(i) == "+") {
      return sum(firstNum, secNum);
    }
    else if (res.charAt(i) == "-") {
      return sub(firstNum, secNum);
    }
    else if (res.charAt(i) == "x") {
      return multi(firstNum, secNum);
    }
    else {
      return div(firstNum, secNum);
    }
    //return firstNum;

  }

    function sum(a, b){
      return a+b;
    }
    function sub(a, b) {
      return a - b;
    }
    function multi(a, b) {
      return a * b;
    }
    function div(a, b) {
      return a / b;
    }


    function addString() {
      var value = $(this).text();
        res += value;
        $("#output").html(res);
    }
    function addStr(event) {
      if (event.keyCode >= 96 && event.keyCode <= 105) {
            res += (event.keyCode - 96);
        } else if (event.keyCode >= 48 && event.keyCode <= 57) {
            res += (event.keyCode - 48);
        }

        if (event.key == "+") {
            res += "+";

        }
        if (event.key == "-") {
            res += "-";

        }
        if (event.key == "*") {
            res += "x";

        }
        if (event.key == "/") {
            res += "/";

        }
        if (event.key == "Enter") {
          var out = determine(res);
          $("#output").html(out);
          res = out.toString();
        }
        $("#output").html(res);

      }


  // check if a number is int or float
  function checkDec(s) {
    if (s.indexOf(".") > -1) { // contains decimal
      return true;
    }
    else {
      return false;
    }
  }
}
